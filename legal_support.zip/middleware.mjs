export { auth as middleware } from "@/lib/auth/auth";
